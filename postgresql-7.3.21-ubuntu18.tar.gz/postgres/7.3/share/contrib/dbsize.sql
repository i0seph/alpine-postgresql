CREATE FUNCTION database_size (name) RETURNS bigint
    AS '$libdir/dbsize', 'database_size'
    LANGUAGE C WITH (isstrict);

CREATE FUNCTION relation_size (text) RETURNS bigint
    AS '$libdir/dbsize', 'relation_size'
    LANGUAGE C WITH (isstrict);
